Snippets I use
