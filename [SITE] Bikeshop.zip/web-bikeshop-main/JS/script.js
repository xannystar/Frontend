$(".wrapper").addClass("loaded")

/* BURGER MENU */
$(".icon-menu").click(function (event) {
  $(this).toggleClass("active")
  $(".menu__body").toggleClass("active")
  $("body").toggleClass("lock")
})

/*--------------------------------------------------------------------------*/

$(document).ready(function () {
  $(".header__burger").click(function (event) {
    $(".header__burger,.header__menu").toggleClass("active")
    $("body").toggleClass("lock")
  })
})

/*--------------------------------------------------------------------------*/

function ibg() {
  $.each($(".ibg"), function (index, val) {
    if ($(this).find("img").length > 0) {
      $(this).css(
        "background-image",
        'url("' + $(this).find("img").attr("src") + '")'
      )
    }
  })
}
ibg()

/*--------------------------------------------------------------------------*/

$(document).ready(function () {
  if ($(".slider__body").length > 0) {
    $(".slider__body").slick({
      adaptiveHeight: true,
      dots: true,
      arrows: false,
      accessibility: false,
      slidesToShow: 1,
      autoplaySpeed: 3000,
      nextArrow: '<button type="button" class="slick-next"></button>',
      prevArrow: '<button type="button" class="slick-prev"></button>',
      responsive: [
        {
          breakpoint: 768,
          settings: {},
        },
      ],
    })
  }
})

/*--------------------------------------------------------------------------*/
